import { Component } from '@angular/core';

@Component({
  selector: 'app-patient-history',
  imports: [],
  templateUrl: './patient-history.html',
  styleUrl: './patient-history.css',
})
export class PatientHistory {

}
