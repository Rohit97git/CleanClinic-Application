import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-interface',
  imports: [],
  templateUrl: './admin-interface.html',
  styleUrl: './admin-interface.css',
})
export class AdminInterface {

}
