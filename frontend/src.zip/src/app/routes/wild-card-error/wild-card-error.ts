import { Component } from '@angular/core';

@Component({
  selector: 'app-wild-card-error',
  imports: [],
  templateUrl: './wild-card-error.html',
  styleUrl: './wild-card-error.css',
})
export class WildCardError {

}
